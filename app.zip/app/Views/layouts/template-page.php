<?= $this->include('layouts/header-page'); ?>
<?= $this->renderSection('content'); ?>
<?= $this->include('layouts/footer'); ?>