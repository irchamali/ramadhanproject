<?= $this->include('layouts/header-program'); ?>
<?= $this->renderSection('content'); ?>
<?= $this->include('layouts/footer'); ?>