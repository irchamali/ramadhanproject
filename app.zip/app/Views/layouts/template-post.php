<?= $this->include('layouts/header-post'); ?>
<?= $this->renderSection('content'); ?>
<?= $this->include('layouts/footer'); ?>