<?= $this->include('layout/header-dashboard'); ?>
<?= $this->renderSection('content'); ?>
<?= $this->include('layout/footer-dashboard'); ?>