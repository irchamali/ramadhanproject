                                    <ul class="navigation clearfix">
										<li><a href="<?= base_url(''); ?>">Home</a>
										</li>
										<li class="dropdown"><a href="#">Tentang</a>
											<ul>
												<li><a href="<?= base_url(''); ?>vmts">Visi Misi</a></li>
												<li><a href="<?= base_url(''); ?>fungsi">Fungsi</a></li>
												<li class="dropdown"><a href="#">Profil</a>
													<ul>
														<li><a href="<?= base_url(''); ?>sejarah">Sejarah</a></li>
														<li><a href="<?= base_url(''); ?>struktur">Struktur Organisasi</a></li>
                                                        <li><a href="<?= base_url(''); ?>pengurus">Kepengurusan</a></li>
													</ul>
												</li>
                                                <li><a href="<?= base_url(''); ?>anggota">Anggota</a></li>
											</ul>
										</li>
										<li class="dropdown"><a href="#">Program</a>
											<ul>
												<li class="dropdown"><a href="#">Program</a>
													<ul>
														<li><a href="<?= base_url(''); ?>program/program-z-chicken">Z Chicken</a></li>
														<li><a href="<?= base_url(''); ?>program/program-z-auto">Z Auto</a></li>
														<li><a href="<?= base_url(''); ?>program/program-santripreneur">Santripreneur</a></li>
														<li><a href="<?= base_url(''); ?>program/program-edukasi-zakat">Edukasi Zakat</a></li>
                                                        <li><a href="<?= base_url(''); ?>program/program-capacity-building-amil">Capacity Building Amil</a></li>
														<li><a href="<?= base_url(''); ?>program/program-literasi-keuangan-syariah">Literasi Keuangan Syariah</a></li>
														<li><a href="<?= base_url(''); ?>program/program-poroz-taawun">POROZ Ta'awun</a></li>
														<li><a href="<?= base_url(''); ?>program/program-pelatihan-umkm">Pelatihan UMKM</a></li>
                                                        <li><a href="<?= base_url(''); ?>program/join-action-for-palestine">Join Action for Palestine</a></li>
													</ul>
												</li>
												<li class="dropdown"><a href="#">Layanan</a>
													<ul>
														<li><a href="<?= base_url(''); ?>service/poroz-institute">POROZ INSTITUT</a></li>
														<li><a href="<?= base_url(''); ?>service/poroz-consulting">POROZ CONSULTING</a></li>
														<li><a href="<?= base_url(''); ?>service/poroz-wilayah">POROZ WILAYAH</a></li>
														
													</ul>
												</li>
											</ul>
										</li>
										<li><a href="/partners">Mitra</a></li>
                                        <!-- <li class="dropdown"><a href="#">Mitra</a>
											<ul>
												<li><a href="<?= base_url(''); ?>mitra">Mitra-mitra</a></li>
												<li><a href="<?= base_url(''); ?>kerjasama">Kerjasama</a></li>
											</ul>
										</li> -->
										<li class="dropdown"><a href="#">Media</a>
											<ul>
												<li><a href="<?= base_url(''); ?>posts">Berita</a></li>
												<li><a href="<?= base_url(''); ?>category/acara">Acara</a></li>
												<li><a href="<?= base_url(''); ?>category/artikel">Artikel</a></li>
                                                <li class="dropdown"><a href="#">Dokumen</a>
													<ul>
                                                        <li><a href="<?= base_url(''); ?>dokumen/buletin">Buletin</a></li>
                                                        <li><a href="<?= base_url(''); ?>dokumen/regulasi">Regulasi Zakat</a></li>
													</ul>
												</li>
											</ul>
										</li>
										<li><a href="/kontak">Kontak</a></li>
									</ul>