<div class="page-footer">
    <p class="no-s"><?= date('Y'); ?> &copy; Powered by Ircham Ali.</p>
</div>