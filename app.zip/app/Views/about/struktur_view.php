<?= $this->extend('layouts/template-page'); ?>
<?= $this->section('content'); ?>
    <!-- Events Detail -->
	<section class="event-detail">
		<div class="auto-container">
			<div class="event-detail_image">
				<img src="<?= base_url(''); ?>assets/backend/images/home/<?= $home['home_bg_testimonial2']; ?>" alt="" />
			</div>
		</div>
	</section>
	<!-- End Events One -->
    
<?= $this->endSection(); ?>