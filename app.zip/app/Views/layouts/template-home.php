<?= $this->include('layouts/header'); ?>
<?= $this->renderSection('content'); ?>
<?= $this->include('layouts/footer'); ?>